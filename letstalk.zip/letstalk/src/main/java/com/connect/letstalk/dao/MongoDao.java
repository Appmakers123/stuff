package com.connect.letstalk.dao;
import java.util.List;
import java.util.Map;

public interface MongoDao
{
		void saveInMongo(Object headerMap,String collection);
    	void updateInMongo(Map<String, Object> object, String collection, String id, Map<String, Number> incObject);	
    	List<Map<String, Object>> getMongoData(Map<String, Object> inputMap, String collection);
    	List<Map<String, Object>> searchMongoData(String search, String collection);
    	
}
