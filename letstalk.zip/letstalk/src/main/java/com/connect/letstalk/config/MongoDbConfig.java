package com.connect.letstalk.config;
//package com.letstalk.config;
//import java.util.Arrays;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
//import org.springframework.core.env.Environment;
//import org.springframework.data.mongodb.MongoDbFactory;
////import org.springframework.data.mongodb.MongoDbFactory;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
//import org.springframework.scheduling.annotation.EnableAsync;
//import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//
//import com.mongodb.MongoClient;
//import com.mongodb.MongoCredential;
//import com.mongodb.ServerAddress;
//
//@Configuration
//@ComponentScan(basePackages = "com.letstalk.controller")
//@EnableWebMvc
//@EnableAsync
//@PropertySource(value = { "file:${letstalk_APP_PROP_PATH_EXT}" }) 
//public class MongoDbConfig {
//	@Autowired
//	private Environment environment;
//
//	@Bean
//	public MongoDbFactory mongoDbFactory() {
//		String mongoPassword = environment.getProperty("mongo.password");
//
//		ServerAddress serverAddress = new ServerAddress(environment.getProperty("host"),
//				Integer.parseInt(environment.getProperty("port")));
//
//		MongoCredential credential = MongoCredential.createCredential(environment.getProperty("mongo.username"),
//				environment.getProperty("database"), mongoPassword.toCharArray());
//		
//		MongoClient mongoClient = new MongoClient(serverAddress, Arrays.asList(credential));
//
//		return new SimpleMongoDbFactory(mongoClient, environment.getProperty("database"));
//	}
//
//	@Bean
//	public MongoTemplate mongoTemplate(){
//		MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
//		return mongoTemplate;
//	} 
//
//
//
//}
