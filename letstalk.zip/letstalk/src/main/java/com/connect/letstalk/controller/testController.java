package com.connect.letstalk.controller;

import java.text.DateFormat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.connect.letstalk.services.userData;



@RestController
@CrossOrigin
public class testController {

	@Autowired
	private userData userdata;
	private static final Logger log = LoggerFactory.getLogger(testController.class);
	//private static final Logger log = LoggerFactory.getLogger(testController.class);
	/*
	 This code is for registration API and method is POST
	 */
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public  Map<String, Object> login(@RequestBody Map<String, Object> requestbody,@RequestHeader Map<String, String> requestheader)
	{
		
		Map<String, Object> result = new HashMap<>();
			
		result = userdata.login(requestbody, requestheader);//pass all the value to implementation class present in service package
			
			return result;
	
	}
	@RequestMapping(value = "/userdata", method = RequestMethod.POST)
	public Map<String, String> userdata(@RequestBody Map<String, String> requestbody,@RequestHeader Map<String, String> requestheader)
	{
			Map<String, String> result = new HashMap<>();
			DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss");       //help to create date format
		    DateFormat df2 = new SimpleDateFormat("dd/MM/yyyy/ HH:mm:ss");
			Date dateobj = new Date();									//to create object of date()
			requestbody.put("Timestamp", df2.format(dateobj));			//put the date into name as Timestamp
			String username = requestbody.get("fname").toString() +requestbody.get("lname").toString()+ df.format(dateobj);//concatenate firstname ,lastname and time stamp to create unique username
			requestbody.put("username", username);
			requestbody.put("status", "A");	
			String contact= requestbody.get("contact_no").toString();
			if(10!=contact.length()) {
				result.put("Error","Invalid length");
				log.error("validating user contact_num");
			}else {
				requestbody.put("_id", requestbody.get("username").toString());	
				String password= requestbody.get("password");
				byte[] byteArray = Base64.encodeBase64(password.getBytes());
				String encodedPassword = new String(byteArray);
				password = encodedPassword;
				String confirmpassword=encodedPassword;
				requestbody.put("password", password);
				requestbody.put("confirmpassword", confirmpassword);
				result = userdata.insertUserData(requestbody, requestheader);
				result.put("Status", "inserted");
				
			} 
			log.info(" user api started having username"+username);
			return result;
	
	}
	/*
	 This code is for createblog API and method is POST
	 */
	@RequestMapping(value = "/createblog", method = RequestMethod.POST)
	public Map<String, String> createblog(@RequestBody Map<String, Object> requestbody,@RequestHeader Map<String, String> requestheader) 
	{
		log.info(" createblog api started");
			Map<String, String> result = new HashMap<>();
			DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss");	 //help to create date format
			DateFormat df2 = new SimpleDateFormat("dd/MM/yyyy/ HH:mm:ss");
			Date dateobj = new Date();								//to create object of date()
			requestbody.put("Timestamp", df2.format(dateobj));
			String blog_id = requestheader.get("username").toString() + df.format(dateobj);//concatenate username and time stamp to create unique blog_id 
			requestbody.put("blog_id", blog_id);								//pass this blog_id to user as a response
			
			requestbody.put("_id", requestheader.get("blog_id"));
			result = userdata.insertcreateblog(requestbody, requestheader);
			log.info(" createblog api started having blog_id"+blog_id);
	
			return result;
	
	}
	/*
	 This code is for getBlog API and method is GET
	 */
	@RequestMapping(value = "/getblog", method = RequestMethod.GET)
	public  List<Map<String,Object>> getblog(@RequestHeader Map<String, String> requestheader) 
	{   
		
	log.info(" Get blog api started");
		List<Map<String,Object>> response = new ArrayList<>();
		 response = userdata.getBlog(requestheader);
		 return response;
	
	}
	
	@RequestMapping(value = "/allBlogs", method = RequestMethod.GET)
	public  List<Map<String,Object>> allBlogs(@RequestHeader Map<String, String> requestheader) 
	{   
		
	log.info(" Get blog api started");
		List<Map<String,Object>> response = new ArrayList<>();
		 response = userdata.allBlogs(requestheader);
		 return response;
	
	}
	/*
	 This code is for editBlog API and method is PUT
	 */
	@RequestMapping(value = "/getpblog", method = RequestMethod.GET)
	public  List<Map<String,Object>> getpblog(@RequestHeader Map<String, String> requestheader) 
	{   
		
	log.info(" Get blog api started");
		List<Map<String,Object>> response = new ArrayList<>();
		 response = userdata.getpBlog(requestheader);
		 return response;
	
	}
		
	@RequestMapping(value = "/editblog", method = RequestMethod.PUT)
	public Map<String, Object> editblog(@RequestBody Map<String, Object> requestBody, @RequestHeader Map<String, String> requestHeader)
	{
		log.info(" editblog api started");
			Map<String, Object> result = new HashMap<>();
		    requestHeader.put("blog_id", requestHeader.get("blog_id"));
		    DateFormat df2 = new SimpleDateFormat("dd/MM/yyyy/ HH:mm:ss");
			Date dateobj = new Date();
			requestBody.put("Timestamp", df2.format(dateobj));
			result = userdata.editblog(requestBody, requestHeader);
			log.info(" editblog api started having blog_id"+requestHeader.get("blog_id"));
			return result;
	
	}
	@RequestMapping(value = "/deleteblog", method = RequestMethod.PUT)
	public Map<String, Object> deleteblog(@RequestHeader Map<String, String> requestHeader)
	{
		log.info("deleteblog api started");
		Map<String, Object> response = new HashMap<>();
		 userdata.deleteblog(requestHeader);
			log.info(" searchblog api started having serach key"+requestHeader);
			response.put("Status_cd", "1");
			return response;
		
	}

	@RequestMapping(value = "/searchblog", method = RequestMethod.GET)
	public List<Map<String,Object>> searchblog(@RequestHeader Map<String, String> requestheader) 
	{
		log.info("searchblog api started");
		List<Map<String, Object>> response = new ArrayList<Map<String, Object>>();
		 response = userdata.search(requestheader);
			log.info(" searchblog api started having serach key"+requestheader);
			
		return  response;
	
	}
	/*
	 This code is for commentdata API and method is POST
	 */
	@RequestMapping(value = "/comment", method = RequestMethod.POST)
	public  Map<String, Object> commentdata(@RequestBody Map<String,Object> requestBody,@RequestHeader  Map<String,String> RequestHeader) 
	{
		log.info(" comment api started");
		Map<String,Object> response = new HashMap();
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy/ HH:mm:ss");
		Date dateobj = new Date();
		requestBody.put("Timestamp", df.format(dateobj));
		response.put("status_cd", "1");
		userdata.commentdata(requestBody, RequestHeader);
		log.info(" commentdata api started having comment info"+response);
		return response;
	
	}
		
	}