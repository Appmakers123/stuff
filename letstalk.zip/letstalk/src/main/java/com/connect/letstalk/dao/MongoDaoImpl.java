/**
 * 
 */
package com.connect.letstalk.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.connect.letstalk.dao.MongoDao;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

@Repository
public class MongoDaoImpl implements MongoDao
{

	private static final Logger log = LoggerFactory.getLogger(MongoDaoImpl.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	public void saveInMongo(Object object, String collection) 
	{
		log.debug("saveInMongo method: START");
		if (object != null) {
			mongoTemplate.save(object.toString(), collection);
			log.debug("saveInMongo method: After inserting in mongo database");
		} else {
			log.debug("saveInMongo method: null Object was passed so no save was performed!!!!");
			
			
		}
		log.debug("saveInMongo method: END");
	}
	
	public void updateInMongo(Map<String, Object> object, String collection, String id, Map<String, Number> incObject) 
	{
		log.debug("updateInMongo method: START");
		Update update = null;
		if (object != null) {
			update = new Update();
			Iterator<String> itr = object.keySet().iterator();
			while (itr.hasNext()) {
				String key = (String) itr.next();
				update.set(key, object.get(key));
			}
		}
		if (incObject != null) {
			update = (update == null) ? new Update() : update;
			Iterator<String> incItr = incObject.keySet().iterator();
			while (incItr.hasNext()) {
				String key = (String) incItr.next();
				update.inc(key, incObject.get(key));
			}
		}
		if (update != null) {
			mongoTemplate.upsert(new Query(Criteria.where("_id").is(id)), update, collection);
			log.debug("updateInMongo method: After updating in mongo database");
		} else {
			log.debug("updateInMongo method: null Object was passed so no save was performed!!!!");
		}
		log.debug("updateInMongo method: END");
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> getMongoData(Map<String, Object> object, String collection)
	{
		log.debug("getMongoData method: START");
		List<Map<String, Object>> result = null;
		if (object != null) {
			Query query = new Query();
			Iterator<String> itr = object.keySet().iterator();
			while (itr.hasNext()) {
				String key = itr.next();
				Object obj = MapUtils.getObject(object, key, "");
				query.addCriteria(Criteria.where(key).is(obj));
			}
			Map<String, Object> map = new HashMap<String, Object>();
			result = (List<Map<String, Object>>) mongoTemplate.find(query, map.getClass(),collection);

			log.debug("getMongoData method: After getting data from mongo database");
		} else {
			log.debug("getMongoData method: null Object was passed so no search was performed!!!!");
		}
		log.debug("getMongoData method: END");
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> searchMongoData(String search, String collection) {

		System.out.println("search key "+search);
		
//		search ="(?i)"+search;
System.out.println("search key "+search);
		BasicDBObject titleObj = new BasicDBObject();
		BasicDBObject domainObj = new BasicDBObject();
		BasicDBObject typeObj = new BasicDBObject();
		BasicDBObject contentObj = new BasicDBObject();
		BasicDBObject orObject = new BasicDBObject();
		BasicDBList list = new BasicDBList();

		MongoDatabase mongoDb = mongoTemplate.getDb();
		MongoCollection<Document> dbCollection = mongoDb.getCollection(collection);
		List<Map<String, Object>> dbList = new ArrayList<Map<String, Object>>();

		//String search2 = search.
		
		titleObj.put("title",new BasicDBObject("$regex",search) );
		domainObj.put("domain",new BasicDBObject("$regex",search) );
		typeObj.put("type",new BasicDBObject("$regex",search) );
		contentObj.put("content",new BasicDBObject("$regex",search) );
		list.add(titleObj);
		list.add(domainObj);
		list.add(typeObj);
		list.add(contentObj);
		orObject.put("$or",list );
		FindIterable<Document> cursor = dbCollection.find(orObject);

	while (((Iterator<DBObject>) cursor).hasNext()) {
		dbList.add((Map<String, Object>) ((Iterator<DBObject>) cursor).next());
		
	}
System.out.println(dbList);
		return dbList;
	}
}
