package com.letstalk.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.letstalk.dao.*;



@Service
public class userDataImpl implements userData{

	@Autowired
	MongoTemplate mongotemplate;

	@Autowired
	MongoDao mongodao;
	
	@Autowired
	Environment env;
	
	private static final Logger log = LoggerFactory.getLogger(userDataImpl.class);

	public Map<String, String> insertUserData(Map<String, String> requestBody, Map<String, String> RequestHeader) {
		Map<String, String> result = new HashMap<String, String>();
		DBObject mongoObj = new BasicDBObject();
		mongoObj.putAll(requestBody);
		DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss");
		Date dateobj = new Date();
		String username = requestBody.get("fname") + requestBody.get("lname") + df.format(dateobj);
		requestBody.put("username", username);
		requestBody.put("status", "A");
		requestBody.put("_id", requestBody.get("username"));
		result.put("username",username );
		result.put("status_cd","1");
		
		mongodao.saveInMongo(mongoObj.toString(), env.getProperty("userdata.collection"));
		log.info(" service class of insertUserData api started");
		return result;
	}

	public Map<String, String> insertcreateblog(Map<String, Object> requestBody, Map<String, String> RequestHeader) {
		Map<String, String> result = new HashMap<String, String>();
		Boolean Auth = HeaderAuth(RequestHeader);
		if (Auth)
		{
			DateFormat df = new SimpleDateFormat("ddMMyyyyHHmmss");
			Date dateobj = new Date();
			String blog_id = RequestHeader.get("username").toString() + df.format(dateobj);
			requestBody.put("blog_id", blog_id);
			requestBody.put("_id", blog_id);
			requestBody.put("username",(String) RequestHeader.get("username").toString());
			DBObject mongoObj = new BasicDBObject();
			mongoObj.putAll(requestBody);
			mongodao.saveInMongo(mongoObj.toString(), env.getProperty("blog.collection"));
			result.put("blog_id",blog_id );
			result.put("status_cd","1");
			log.info(" service class of insertcreateblog api started");
		} else {
			result.put("status_cd", "0");
			log.info(" service class of insertcreateblog not api started");
		}
		return result;

	}
	
	public Map<String, Object> editblog(Map<String, Object> requestBody, Map<String, String> RequestHeader)
	{	Map<String, Object> result = new HashMap<String, Object>();
		Boolean Auth = HeaderAuth(RequestHeader);
		if (Auth) {
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy/ HH:mm:ss");
			Date dateobj = new Date();
			requestBody.put("Timestamp", df.format(dateobj));
			DBObject mongoObj = new BasicDBObject();
			mongoObj.putAll(requestBody);
			mongodao.updateInMongo(requestBody, env.getProperty("blog.collection"),	RequestHeader.get("blog_id").toString(), null);
			log.info(" service class of editblog api started");
			result.put("username", RequestHeader.get("username"));
			result.put("status_cd", "1");
		} else {
			result.put("status_cd", "0");
			log.info(" service class of editblog not api started");
		}
		return result;
	}
	public Map<String,Object> filterMap1( Map<String,String> inputMap)
	{
		 Map<String,Object> outputMap = new HashMap<String, Object>();

		 if(inputMap.containsKey("username"))
		 {
			 outputMap.put("username", inputMap.get("username"));
		 }
		 else
		 {
			 outputMap.put("status_cd","0");
		 }
	return outputMap;
	}
	
	public List<Map<String,Object>> getBlog(Map<String, String> requestheader)
	{
		Map<String, Object> result = new HashMap<String, Object>();
		Boolean Auth = HeaderAuth(requestheader);
		if (Auth) {
		Map<String, Object> DbSearchMap = new HashMap<String, Object>();
		DbSearchMap = filterMap1(requestheader);
		List<Map<String, Object>> mongoData = mongodao.getMongoData(DbSearchMap, env.getProperty("blog.collection"));
		Iterator <Map<String,Object>> itr = mongoData.iterator();
		log.info(" service class of getBlog api started");
	  	while(itr.hasNext())	
		{
	  		result= itr.next();
	  	    result.remove("_id");
	        result.remove("Timestamp");
	        log.info(" service class of getBlog  api started");
		}
		return   mongoData; 
	}
		else {
			result.put("status_cd", "0");
			log.info(" service class of getBlog  api not  started");
		}
		return null;
	}
	public List<Map<String, Object>> allBlogs(Map<String, String> requestheader) {
		Map<String, Object> result = new HashMap<String, Object>();
	
		Map<String, Object> DbSearchMap = new HashMap<String, Object>();
		List<Map<String, Object>> mongoData = mongodao.getMongoData(DbSearchMap, env.getProperty("blog.collection"));
		Iterator <Map<String,Object>> itr = mongoData.iterator();
		log.info(" service class of getBlog api started");
	  	while(itr.hasNext())	
		{
	  		result= itr.next();
	  	    result.remove("_id");
	        result.remove("Timestamp");
	        log.info(" service class of getBlog  api started");
		}
		return   mongoData; 
	
	}
	
	
	public List<Map<String,Object>> search(Map<String, String> requestheader)
	{
		Map<String, Object> result = new HashMap<String, Object>();

		List<Map<String, Object>> mongoData = mongodao.searchMongoData(requestheader.get("search"), env.getProperty("blog.collection"));
		
		
		
		Iterator <Map<String,Object>> itr = mongoData.iterator();
		log.info(" service class of search api started");
	  	while(itr.hasNext())	
		{
	  		result= itr.next();
	  	    result.remove("_id");
	        result.remove("Timestamp");
	        result.put("status_cd", "1");
		}
	          
		return   mongoData; 
	}
	public void commentdata(Map<String,Object> requestBody,Map<String,String> RequestHeader)
	{   Map<String, Object> result = new HashMap<String, Object>();
		Boolean Auth = HeaderAuth(RequestHeader);
		if (Auth) {
		Query query = new Query();
		log.info(" service class of commentdata api started");
		query.addCriteria(Criteria.where("blog_id").is(RequestHeader.get("blog_id")));
		Update update = new Update();
		requestBody.put("username", RequestHeader.get("username"));
		update.push("comment", requestBody);
		mongotemplate.updateFirst(query, update, env.getProperty("blog.collection"));
		}
		else {
		result.put("status_cd", "0");
		log.info(" service class of commentdata api not started");}
	}
	
	public Boolean HeaderAuth(Map<String,String> requestheader) 
	{   
		
		Map<String, Object> inputMap = new HashMap<String, Object>();
		Map<String, Object> result1 = new HashMap<String, Object>();
		Boolean result = false;
		inputMap.put("username", requestheader.get("username"));
		System.out.println("username"+requestheader.get("username"));
		List<Map<String, Object>> mongoData = mongodao.getMongoData(inputMap, env.getProperty("userdata.collection"));
		System.out.println("mongoData"+mongoData);
		if(mongoData.size() > 0) 
		{
		result1 = mongoData.get(0);
		String password = result1.get("password").toString();
		
		byte[] byteArray = Base64.decodeBase64(password.getBytes());
		
		String decodedPassword = new String(byteArray);
		System.out.println("decodedPassword "+decodedPassword);
		password = decodedPassword;
		requestheader.put("password", password);
		
		String status = result1.get("status").toString();
		if("A".equalsIgnoreCase(status) && password.equals(requestheader.get("password").toString())) 
		   {
			result = true;

			} else
			{
			result = false;
			}

			} else
			{
			result = false;
			}

		   return result;
     }


	public Map<String, Object> login(Map<String, Object> requestbody, Map<String, String> requestheader) {
		Boolean Auth = HeaderAuth(requestheader);
		Map<String, Object> result = new HashMap<String, Object>();
		if (Auth) {
			
			result.put("message", "Login Successful");
			result.put("status_cd", "1");
			}
			else {
				
				result.put("message", "Login Failed");
				result.put("status_cd", "0");
			
	}
		return result;
	}

	public void deleteblog(Map<String, String> requestHeader) {
		Map<String, Object> result = new HashMap<String, Object>();
		String blog_id=  requestHeader.get("blog_id").toString();
		
		
		Map<String, Object> productMap = new HashMap<String, Object>();
		productMap.put("_id", blog_id);
		DBObject mongoObj1 = new BasicDBObject();

		mongoObj1.putAll(productMap);
	
		mongotemplate.remove(mongoObj1, env.getProperty("blog.collection"));
		
	}
	public Map<String,Object> filterMap( Map<String,String> inputMap)
	{
		 Map<String,Object> outputMap = new HashMap<String, Object>();

		 if(inputMap.containsKey("blog_id"))
		 {
			 outputMap.put("blog_id", inputMap.get("blog_id"));
		 }
		 else
		 {
			 outputMap.put("status_cd","0");
		 }
	return outputMap;
	}

	public List<Map<String, Object>> getpBlog(Map<String, String> requestheader) {
		Map<String, Object> result = new HashMap<String, Object>();
		Boolean Auth = HeaderAuth(requestheader);
		if (Auth) {
		Map<String, Object> DbSearchMap = new HashMap<String, Object>();
		DbSearchMap = filterMap(requestheader);
		List<Map<String, Object>> mongoData = mongodao.getMongoData(DbSearchMap, env.getProperty("blog.collection"));
		Iterator <Map<String,Object>> itr = mongoData.iterator();
		log.info(" service class of getBlog api started");
	  	while(itr.hasNext())	
		{
	  		result= itr.next();
	  	    result.remove("_id");
	        result.remove("Timestamp");
	        log.info(" service class of getpBlog  api started");
		}
		return   mongoData; 
	}
		else {
			result.put("status_cd", "0");
			log.info(" service class of getpBlog  api not  started");
		}
		return null;
	}


	
		
	}
