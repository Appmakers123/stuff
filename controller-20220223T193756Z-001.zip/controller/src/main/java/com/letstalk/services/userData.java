package com.letstalk.services;
import java.util.List;
import java.util.Map;

public interface userData
	{
	public Map<String,String> insertUserData(Map<String,String> requestBody,Map<String,String> RequestHeader);
	public Map<String, String> insertcreateblog(Map<String, Object> requestBody,Map<String, String> RequestHeader);
	public List<Map<String, Object>> getBlog(Map<String, String> requestheader);
	public Map<String, Object> editblog(Map<String, Object> requestBody, Map<String, String> RequestHeader);
	public List<Map<String,Object>> search(Map<String, String> requestheader);
	public void commentdata(Map<String,Object> requestBody,Map<String,String> RequestHeader);
	public Map<String, Object> login(Map<String, Object> requestbody, Map<String, String> requestheader);
	public List<Map<String, Object>> allBlogs(Map<String, String> requestheader);
	public void deleteblog(Map<String, String> requestHeader);
	public List<Map<String, Object>> getpBlog(Map<String, String> requestheader);
	}
